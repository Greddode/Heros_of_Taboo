#ifndef INPUT_SYSTEM_H
#define INPUT_SYSTEM_H

#include "world.h"
#include "ui/inventory_ui.h"

// TODO: change to GameWorld* once textures move to ResourceManager in step 10
typedef struct Game Game;
void InputSystem_Inventory(Game* game, InventoryUIState* ui);
void InputSystem_PlayerTurn(Game* game, InventoryUIState* ui);

#endif